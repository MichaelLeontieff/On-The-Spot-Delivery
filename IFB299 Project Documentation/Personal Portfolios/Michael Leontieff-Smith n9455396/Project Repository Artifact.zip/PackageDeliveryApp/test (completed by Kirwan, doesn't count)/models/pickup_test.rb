require 'test_helper'

class PickupTest < ActiveSupport::TestCase
  # test "the truth" do
  #   assert true
  # end
end
