require 'test_helper'

class CheckinginTest < ActiveSupport::TestCase
  # test "the truth" do
  #   assert true
  # end
end
