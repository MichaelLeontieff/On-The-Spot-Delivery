module OperatorsHelper
end
