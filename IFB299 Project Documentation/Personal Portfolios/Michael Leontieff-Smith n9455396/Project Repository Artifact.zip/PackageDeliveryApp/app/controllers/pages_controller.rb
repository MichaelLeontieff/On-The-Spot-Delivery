# Pages Controller
#
# Empty Pages controller, no helper methods required for static pages

class PagesController < ApplicationController

end