require 'test_helper'

class SessionsControllerTest < ActionDispatch::IntegrationTest
  

end
